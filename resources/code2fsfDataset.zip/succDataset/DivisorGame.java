public class DivisorGame {

    public static boolean divisorGame(int n) {
        return n % 2 == 0;
    }
}
