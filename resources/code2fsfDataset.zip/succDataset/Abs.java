public class Abs {

    public static int Abs(int num) {
        if (num < 0)
            return -num;
        else
            return num;
    }
}
