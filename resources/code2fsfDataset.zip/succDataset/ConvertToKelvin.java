class ConvertToKelvin {

    public static double convertTemperature(double celsius) {
        return celsius + 273.15;
    }
}
