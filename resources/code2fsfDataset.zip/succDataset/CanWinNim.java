class CanWinNim {

    public static boolean canWinNim(int n) {
        return n % 4 != 0;
    }
}
