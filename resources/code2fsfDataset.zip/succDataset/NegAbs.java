public class NegAbs {

    public static int negAbs(int num) {
        if (num < 0)
            return num;
        else
            return -num;
    }
}
