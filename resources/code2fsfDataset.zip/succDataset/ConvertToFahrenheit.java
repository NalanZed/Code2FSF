class ConvertToFahrenheit {

    public static double convertTemperature(double celsius) {
        return celsius * 1.80 + 32.00;
    }
}
