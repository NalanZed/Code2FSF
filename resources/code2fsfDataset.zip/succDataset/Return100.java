public class Return100 {
    public static int return100 () {
        int res = 0;
        for(int i = 0; i < 100; i++) {
            res = res + 1;
        }
        return res;
    }
}
