public class ReLUSeq {
    public static double computeReLU(double x) {
        return ((x >= 0) ? x : 0);
    }
}