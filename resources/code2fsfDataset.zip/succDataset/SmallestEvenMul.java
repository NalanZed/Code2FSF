class SmallestEvenMul {

    public static int smallestEvenMultiple(int n) {
        if (n % 2 == 0) {
            return n;
        } else {
            return 2 * n;
        }
        //        return n % 2 == 0 ? n : 2 * n;
    }
}
