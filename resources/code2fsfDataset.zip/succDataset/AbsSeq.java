public class AbsSeq {

    public static int Abs(int num) {
        return ((num < 0) ? (-num) : (num));
    }
}
